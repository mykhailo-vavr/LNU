﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Diagnostics;

namespace MV_PC_Lab_8
{
    public class Calculations
    {
        static List<string> GetRowsWithSpecificChars(List<string> rows, List<string> specificChars) {
            List<string> filteredRows = new List<string>();

            foreach (string row in rows)
            {
                foreach (string specificChar in specificChars)
                {
                    if(row.Contains(specificChar))
                    {
                        filteredRows.Add(row);
                    }
                }
            }

            return filteredRows;
        }

        private static object threadLock = new object();

        public static void RunInOneThread(List<string> inputDatas, List<string> specificChars, List<int> threadsOrder, List<(List<string> str, long ms)> results)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();
            threadsOrder.Add(Thread.CurrentThread.ManagedThreadId);
            foreach (string str in inputDatas)
            {
                List<string> rows = new List<string>(str.Split("\n"));

                List<string> filteredRows = Calculations.GetRowsWithSpecificChars(rows, specificChars);

                results.Add((filteredRows, -1));
            }

            stopwatch.Stop();

            for (int i = 0; i < results.Count; i++)
            {
                results[i] = (results[i].str, stopwatch.ElapsedMilliseconds);
            }
        }

        public static void RunInManyThreads(List<string> inputDatas, List<string> specificChars, List<int> threadsOrder, List<(List<string> str, long ms)> results)
        {
            int countOfThreads = inputDatas.Count;
            int finishedThreads = 0;

            List<Thread> threads = new List<Thread>();

            foreach (string str in inputDatas)
            {
                threads.Add(
                    new Thread((object obj) => {
                        lock(threadLock)
                        {
                            Stopwatch stopwatch = new Stopwatch();
                            stopwatch.Start();

                            (
                                string str,
                                List<string> specificChars,
                                List<int> threadsOrder,
                                List<(List<string> str, long ms)> results
                            ) data = ((
                                    string str,
                                    List<string> specificChars,
                                    List<int> threadsOrder,
                                    List<(List<string> str, long ms)> results
                                ))obj;

                            data.threadsOrder.Add(Thread.CurrentThread.ManagedThreadId);


                            List<string> rows = new List<string>(data.str.Split("\n"));
                            List<string> filteredRows = Calculations.GetRowsWithSpecificChars(rows, data.specificChars);

                        
                            stopwatch.Stop();

                            data.results.Add((filteredRows, stopwatch.ElapsedMilliseconds));
                        }

                        finishedThreads++;
                    })
                );
            }

            for (int i = countOfThreads / 2; i > -1; i--)
            {
                threads[i].Start((inputDatas[i], specificChars, threadsOrder, results));
            }

            while (finishedThreads <= countOfThreads / 2)
            {
                continue;
            }

            for (int i = countOfThreads / 2 + 1; i < countOfThreads; i++)
            {
                threads[i].Start((inputDatas[i], specificChars, threadsOrder, results));
            }

            while (finishedThreads != countOfThreads)
            {
                continue;
            }
        }
    }
}
