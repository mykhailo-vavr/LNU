﻿using System;
using System.Collections.Generic;

namespace MV_PC_Lab_8
{
    class File
    {
        public static string GetBasePath()
        {
            string runPath = AppDomain.CurrentDomain.BaseDirectory;
            List<string> pathChunks = new List<string>(runPath.Split(@"\"));
            pathChunks.RemoveRange(pathChunks.Count - 5, 5);
            return string.Join(@"\", pathChunks);
        }

        public static string ReadFromFile(string path)
        {
            return System.IO.File.ReadAllText(path);
        }

        public static async void WriteIntoFile(string text)
        {
            await System.IO.File.WriteAllTextAsync(@$"{GetBasePath()}\outputData.txt", text);
        }
    }
}
