﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;

namespace MV_PC_Lab_8
{
    public partial class Form1 : Form
    {
        private readonly List<string> inputDatas = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void chooseFileButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();

            openFileDialog.InitialDirectory = File.GetBasePath();
            openFileDialog.Filter = "Text|*.txt|All|*.*";
            openFileDialog.FilterIndex = 0;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog.FileName;

                filesPathesTextBox.AppendText(path);
                filesPathesTextBox.AppendText(Environment.NewLine);

                string inputData = File.ReadFromFile(path);

                inputDatas.Add(inputData);
                inputDataTextBox.AppendText($"## File path: {path} ##");
                inputDataTextBox.AppendText($"{Environment.NewLine}{Environment.NewLine}");
                inputDataTextBox.AppendText(inputData);
                inputDataTextBox.AppendText($"{Environment.NewLine}{Environment.NewLine}===================={Environment.NewLine}{Environment.NewLine}");
            }
        }

        private void runCalculationsButton_Click(object sender, EventArgs e)
        {
            if (inputDatas.Count == 0)
            {
                return;
            }

            resultTextBox.Clear();

            List<string> specificChars = new List<string>(specificCharsTextBox.Text.Split(" "));
            bool runInManyThreads = runInManyThreadsCheckbox.Checked;
            List<int> threadsOrder = new List<int>();
            List<(List<string> str, long ms)> results = new List<(List<string> str, long ms)>();

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            if (runInManyThreads)
            {
                Calculations.RunInManyThreads(inputDatas, specificChars, threadsOrder, results);
            }
            else
            {
                Calculations.RunInOneThread(inputDatas, specificChars, threadsOrder, results);
            }

            stopwatch.Stop();

            // Show calculation time

            calculationTimeTextBox.Text = $"{stopwatch.ElapsedMilliseconds} ms";

            // Show threads order

            threadsOrderTextBox.Text = string.Join(", ", threadsOrder);

            // Write data to file
            string text = "";

            foreach (var (str, ms) in results)
            {
                text +=
                    $"Thread execution time: {ms}ms \n\n" +
                    $"{string.Join("\n", str)}\n\n====================\n\n";
            }

            File.WriteIntoFile(text);

            // Show result in tab

            resultTextBox.Text = text.Replace("\n", Environment.NewLine);

        }
    }
}
