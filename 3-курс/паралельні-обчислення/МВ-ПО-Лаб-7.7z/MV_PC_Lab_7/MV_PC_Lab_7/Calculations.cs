﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Linq;
using System.Diagnostics;

namespace MV_PC_Lab_7
{
    public class Calculations
    {
        static double GetAverageWordLength(string str)
        {
            char[] punctuation = { ' ', '.', ',', '!', '?', ':', ';', '(', ')', '\n' };
            return str.Split(punctuation).Average(word => word.Length);
        }

        static string GetLongestWhitespace(string str)
        {
            string text = string.Join("", str.Split('\n'));

            int largestCount = 0;
            int currentCount = 0;

            foreach (char character in text)
            {
                if (character != ' ')
                {
                    currentCount = 0;
                }
                else
                {
                    currentCount++;
                }

                if (currentCount >= largestCount)
                {
                    largestCount = currentCount;
                }
            }

            return new string(' ', largestCount);
        }

        static string[] GetTenLongestWords(string str)
        {
            char[] punctuation = { ' ', '.', ',', '!', '?', ':', ';', '(', ')', '\n' };

            string[] arr = str.Split(punctuation);

            Array.Sort(arr, (a, b) => a.Length - b.Length);

            return arr.TakeLast(10).ToArray();
        }

        public static void RunInOneThread(List<string> inputDatas, List<int> threadsOrder, List<(double, string, string[])> results, List<long> calculationTime)
        {
            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            threadsOrder.Add(Thread.CurrentThread.ManagedThreadId);
            foreach (string str in inputDatas)
            {

                double averageWordLength = Calculations.GetAverageWordLength(str);
                string longestWhitespace = Calculations.GetLongestWhitespace(str);
                string[] tenLongestWords = Calculations.GetTenLongestWords(str);

                results.Add((averageWordLength, longestWhitespace, tenLongestWords));
            }

            stopwatch.Stop();
            calculationTime.Add(stopwatch.ElapsedMilliseconds);
        }

        public static void RunInManyThreads(List<string> inputDatas, List<int> threadsOrder, List<(double, string, string[])> results, List<long> calculationTime)
        {
            int countOfThreads = inputDatas.Count;
            int finishedThreads = 0;

            foreach (string str in inputDatas)
            {
                Thread thread = new Thread((object obj) => {
                    Stopwatch stopwatch = new Stopwatch();
                    stopwatch.Start();

                    (
                        string str,
                        List<int> threadsOrder,
                        List<(double, string, string[])> results,
                        List<long> calculationTime
                    ) data = ((
                            string str,
                            List<int> threadsOrder,
                            List<(double, string, string[])> results,
                            List<long> calculationTime
                        ))obj;

                    data.threadsOrder.Add(Thread.CurrentThread.ManagedThreadId);

                    double averageWordLength = Calculations.GetAverageWordLength(data.str);
                    string longestWhitespace = Calculations.GetLongestWhitespace(data.str);
                    string[] tenLongestWords = Calculations.GetTenLongestWords(data.str);

                    data.results.Add((averageWordLength, longestWhitespace, tenLongestWords));
                    finishedThreads++;

                    stopwatch.Stop();
                    data.calculationTime.Add(stopwatch.ElapsedMilliseconds);
                });

                thread.Start((str, threadsOrder, results, calculationTime));
            }

            while (finishedThreads != countOfThreads)
            {
                continue;
            }
        }
    }
}
