﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using System.Diagnostics;

namespace MV_PC_Lab_7
{
    public partial class Form1 : Form
    {
        private readonly List<string> inputDatas = new List<string>();

      
        public Form1()
        {
            InitializeComponent();
        }

        private void chooseFileButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                InitialDirectory = File.GetBasePath(),
                Filter = "Text|*.txt|All|*.*",
                FilterIndex = 0,
                RestoreDirectory = true
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string path = openFileDialog.FileName;

                filesPathesTextBox.AppendText(path);
                filesPathesTextBox.AppendText(Environment.NewLine);

                string inputData = File.ReadFromFile(path);

                inputDatas.Add(inputData);
                inputDataTextBox.AppendText($"## File path: {path} ##");
                inputDataTextBox.AppendText($"{Environment.NewLine}{Environment.NewLine}");
                inputDataTextBox.AppendText(inputData);
                inputDataTextBox.AppendText($"{Environment.NewLine}{Environment.NewLine}===================={Environment.NewLine}{Environment.NewLine}");
            }
        }

        private void runCalculationsButton_Click(object sender, EventArgs e)
        {
            if(inputDatas.Count == 0)
            {
                return;
            }

            resultTextBox.Clear();

            bool runInManyThreads = runInManyThreadsCheckbox.Checked;
            List<int> threadsOrder = new List<int>();
            List<(double, string, string[])> results = new List<(double, string, string[])>();
            List<long> calculationTime = new List<long>();

            Stopwatch stopwatch = new Stopwatch();
            stopwatch.Start();

            if (runInManyThreads)
            {
                Calculations.RunInManyThreads(inputDatas, threadsOrder, results, calculationTime);
            }
            else
            {
                Calculations.RunInOneThread(inputDatas, threadsOrder, results, calculationTime);
            }

            stopwatch.Stop();

            // Show calculation time

            calculationTimeTextBox.Text = $"{stopwatch.ElapsedMilliseconds} ms";

            // Show threads order

            threadsOrderTextBox.Text = string.Join(", ", threadsOrder);

            // Write data to file

            List<string> resultsStrings = new List<string>();
            foreach (var result in results)
            {
                resultsStrings.Add(
                    $"Average word length: {result.Item1}{Environment.NewLine}" +
                    $"Longest whitespace length: {result.Item2.Length}{Environment.NewLine}" +
                    $"Ten longest words: {string.Join(", ", result.Item3)}"
                );
            }

            string text =
                "Threads execution time (ms): " +
                string.Join(", ", calculationTime) + 
                "\n\n" +
                string.Join("\n\n====================\n\n", resultsStrings);


            File.WriteIntoFile(text);

            // Show result in tab

            resultTextBox.Text = text.Replace("\n", Environment.NewLine);

        }
    }
}
