﻿
namespace MV_PC_Lab_7
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.readmePage = new System.Windows.Forms.TabPage();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chooseFilePage = new System.Windows.Forms.TabPage();
            this.filesPathesTextBox = new System.Windows.Forms.TextBox();
            this.chooseFileButton = new System.Windows.Forms.Button();
            this.runPage = new System.Windows.Forms.TabPage();
            this.calculationTimeTextBox = new System.Windows.Forms.TextBox();
            this.threadsOrderTextBox = new System.Windows.Forms.TextBox();
            this.calculationTimeLabel = new System.Windows.Forms.Label();
            this.threadsOrderLabel = new System.Windows.Forms.Label();
            this.runInManyThreadsCheckbox = new System.Windows.Forms.CheckBox();
            this.runCalculationsButton = new System.Windows.Forms.Button();
            this.inputDataPage = new System.Windows.Forms.TabPage();
            this.inputDataTextBox = new System.Windows.Forms.TextBox();
            this.resultPage = new System.Windows.Forms.TabPage();
            this.resultTextBox = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.readmePage.SuspendLayout();
            this.chooseFilePage.SuspendLayout();
            this.runPage.SuspendLayout();
            this.inputDataPage.SuspendLayout();
            this.resultPage.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.readmePage);
            this.tabControl1.Controls.Add(this.chooseFilePage);
            this.tabControl1.Controls.Add(this.runPage);
            this.tabControl1.Controls.Add(this.inputDataPage);
            this.tabControl1.Controls.Add(this.resultPage);
            this.tabControl1.Location = new System.Drawing.Point(1, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(804, 455);
            this.tabControl1.TabIndex = 1;
            // 
            // readmePage
            // 
            this.readmePage.Controls.Add(this.label3);
            this.readmePage.Controls.Add(this.label2);
            this.readmePage.Controls.Add(this.label1);
            this.readmePage.Location = new System.Drawing.Point(4, 34);
            this.readmePage.Name = "readmePage";
            this.readmePage.Padding = new System.Windows.Forms.Padding(3);
            this.readmePage.Size = new System.Drawing.Size(796, 417);
            this.readmePage.TabIndex = 6;
            this.readmePage.Text = "Readme";
            this.readmePage.UseVisualStyleBackColor = true;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.SystemColors.MenuText;
            this.label3.Location = new System.Drawing.Point(7, 368);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(368, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Mykhailo Vavrykovych, AMI-33, v. 5, 2022";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.DarkGoldenrod;
            this.label2.Location = new System.Drawing.Point(7, 12);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(536, 250);
            this.label2.TabIndex = 1;
            this.label2.Text = resources.GetString("label2.Text");
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 262);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(510, 75);
            this.label1.TabIndex = 0;
            this.label1.Text = "Task:\r\n    У текстовому файлі потік підраховує: 1) середню довжину\r\n    слова, 2)" +
    " саме довге \"біле\" поле, 3) 10 самих довгих слів.\r\n";
            // 
            // chooseFilePage
            // 
            this.chooseFilePage.Controls.Add(this.filesPathesTextBox);
            this.chooseFilePage.Controls.Add(this.chooseFileButton);
            this.chooseFilePage.Location = new System.Drawing.Point(4, 34);
            this.chooseFilePage.Name = "chooseFilePage";
            this.chooseFilePage.Size = new System.Drawing.Size(796, 417);
            this.chooseFilePage.TabIndex = 5;
            this.chooseFilePage.Text = "Choose file";
            this.chooseFilePage.UseVisualStyleBackColor = true;
            // 
            // filesPathesTextBox
            // 
            this.filesPathesTextBox.Location = new System.Drawing.Point(43, 90);
            this.filesPathesTextBox.Multiline = true;
            this.filesPathesTextBox.Name = "filesPathesTextBox";
            this.filesPathesTextBox.PlaceholderText = "You didn\'t choose any files...";
            this.filesPathesTextBox.ReadOnly = true;
            this.filesPathesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.filesPathesTextBox.Size = new System.Drawing.Size(707, 173);
            this.filesPathesTextBox.TabIndex = 2;
            // 
            // chooseFileButton
            // 
            this.chooseFileButton.Location = new System.Drawing.Point(43, 35);
            this.chooseFileButton.Name = "chooseFileButton";
            this.chooseFileButton.Size = new System.Drawing.Size(707, 40);
            this.chooseFileButton.TabIndex = 1;
            this.chooseFileButton.Text = "Choose file";
            this.chooseFileButton.UseVisualStyleBackColor = true;
            this.chooseFileButton.Click += new System.EventHandler(this.chooseFileButton_Click);
            // 
            // runPage
            // 
            this.runPage.Controls.Add(this.calculationTimeTextBox);
            this.runPage.Controls.Add(this.threadsOrderTextBox);
            this.runPage.Controls.Add(this.calculationTimeLabel);
            this.runPage.Controls.Add(this.threadsOrderLabel);
            this.runPage.Controls.Add(this.runInManyThreadsCheckbox);
            this.runPage.Controls.Add(this.runCalculationsButton);
            this.runPage.Location = new System.Drawing.Point(4, 34);
            this.runPage.Name = "runPage";
            this.runPage.Padding = new System.Windows.Forms.Padding(3);
            this.runPage.Size = new System.Drawing.Size(796, 417);
            this.runPage.TabIndex = 2;
            this.runPage.Text = "Run";
            this.runPage.UseVisualStyleBackColor = true;
            // 
            // calculationTimeTextBox
            // 
            this.calculationTimeTextBox.Location = new System.Drawing.Point(43, 278);
            this.calculationTimeTextBox.Name = "calculationTimeTextBox";
            this.calculationTimeTextBox.ReadOnly = true;
            this.calculationTimeTextBox.Size = new System.Drawing.Size(711, 31);
            this.calculationTimeTextBox.TabIndex = 7;
            // 
            // threadsOrderTextBox
            // 
            this.threadsOrderTextBox.Location = new System.Drawing.Point(43, 185);
            this.threadsOrderTextBox.Name = "threadsOrderTextBox";
            this.threadsOrderTextBox.ReadOnly = true;
            this.threadsOrderTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.threadsOrderTextBox.Size = new System.Drawing.Size(711, 31);
            this.threadsOrderTextBox.TabIndex = 6;
            // 
            // calculationTimeLabel
            // 
            this.calculationTimeLabel.AutoSize = true;
            this.calculationTimeLabel.Location = new System.Drawing.Point(38, 242);
            this.calculationTimeLabel.Name = "calculationTimeLabel";
            this.calculationTimeLabel.Size = new System.Drawing.Size(138, 25);
            this.calculationTimeLabel.TabIndex = 5;
            this.calculationTimeLabel.Text = "Calculation time";
            // 
            // threadsOrderLabel
            // 
            this.threadsOrderLabel.AutoSize = true;
            this.threadsOrderLabel.Location = new System.Drawing.Point(38, 152);
            this.threadsOrderLabel.Name = "threadsOrderLabel";
            this.threadsOrderLabel.Size = new System.Drawing.Size(122, 25);
            this.threadsOrderLabel.TabIndex = 4;
            this.threadsOrderLabel.Text = "Threads order";
            // 
            // runInManyThreadsCheckbox
            // 
            this.runInManyThreadsCheckbox.AutoSize = true;
            this.runInManyThreadsCheckbox.Location = new System.Drawing.Point(43, 89);
            this.runInManyThreadsCheckbox.Name = "runInManyThreadsCheckbox";
            this.runInManyThreadsCheckbox.Size = new System.Drawing.Size(320, 29);
            this.runInManyThreadsCheckbox.TabIndex = 3;
            this.runInManyThreadsCheckbox.Text = "Run calculations in separate threads";
            this.runInManyThreadsCheckbox.UseVisualStyleBackColor = true;
            // 
            // runCalculationsButton
            // 
            this.runCalculationsButton.Location = new System.Drawing.Point(43, 34);
            this.runCalculationsButton.Name = "runCalculationsButton";
            this.runCalculationsButton.Size = new System.Drawing.Size(711, 40);
            this.runCalculationsButton.TabIndex = 2;
            this.runCalculationsButton.Text = "Run calculations";
            this.runCalculationsButton.UseVisualStyleBackColor = true;
            this.runCalculationsButton.Click += new System.EventHandler(this.runCalculationsButton_Click);
            // 
            // inputDataPage
            // 
            this.inputDataPage.Controls.Add(this.inputDataTextBox);
            this.inputDataPage.Location = new System.Drawing.Point(4, 34);
            this.inputDataPage.Name = "inputDataPage";
            this.inputDataPage.Padding = new System.Windows.Forms.Padding(3);
            this.inputDataPage.Size = new System.Drawing.Size(796, 417);
            this.inputDataPage.TabIndex = 3;
            this.inputDataPage.Text = "Input data";
            this.inputDataPage.UseVisualStyleBackColor = true;
            // 
            // inputDataTextBox
            // 
            this.inputDataTextBox.Location = new System.Drawing.Point(6, 3);
            this.inputDataTextBox.Multiline = true;
            this.inputDataTextBox.Name = "inputDataTextBox";
            this.inputDataTextBox.ReadOnly = true;
            this.inputDataTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.inputDataTextBox.Size = new System.Drawing.Size(787, 401);
            this.inputDataTextBox.TabIndex = 0;
            // 
            // resultPage
            // 
            this.resultPage.Controls.Add(this.resultTextBox);
            this.resultPage.Location = new System.Drawing.Point(4, 34);
            this.resultPage.Name = "resultPage";
            this.resultPage.Padding = new System.Windows.Forms.Padding(3);
            this.resultPage.Size = new System.Drawing.Size(796, 417);
            this.resultPage.TabIndex = 4;
            this.resultPage.Text = "Result";
            this.resultPage.UseVisualStyleBackColor = true;
            // 
            // resultTextBox
            // 
            this.resultTextBox.Location = new System.Drawing.Point(5, 8);
            this.resultTextBox.Multiline = true;
            this.resultTextBox.Name = "resultTextBox";
            this.resultTextBox.ReadOnly = true;
            this.resultTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.resultTextBox.Size = new System.Drawing.Size(787, 401);
            this.resultTextBox.TabIndex = 1;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "MV_PC_Lab_7";
            this.tabControl1.ResumeLayout(false);
            this.readmePage.ResumeLayout(false);
            this.readmePage.PerformLayout();
            this.chooseFilePage.ResumeLayout(false);
            this.chooseFilePage.PerformLayout();
            this.runPage.ResumeLayout(false);
            this.runPage.PerformLayout();
            this.inputDataPage.ResumeLayout(false);
            this.inputDataPage.PerformLayout();
            this.resultPage.ResumeLayout(false);
            this.resultPage.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage runPage;
        private System.Windows.Forms.TabPage inputDataPage;
        private System.Windows.Forms.CheckBox runInManyThreadsCheckbox;
        private System.Windows.Forms.Button runCalculationsButton;
        private System.Windows.Forms.TabPage resultPage;
        private System.Windows.Forms.TabPage chooseFilePage;
        private System.Windows.Forms.Label threadsOrderLabel;
        private System.Windows.Forms.TextBox inputDataTextBox;
        private System.Windows.Forms.TextBox resultTextBox;
        private System.Windows.Forms.Label calculationTimeLabel;
        private System.Windows.Forms.TextBox calculationTimeTextBox;
        private System.Windows.Forms.TextBox threadsOrderTextBox;
        private System.Windows.Forms.TabPage readmePage;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox filesPathesTextBox;
        private System.Windows.Forms.Button chooseFileButton;
    }
}

